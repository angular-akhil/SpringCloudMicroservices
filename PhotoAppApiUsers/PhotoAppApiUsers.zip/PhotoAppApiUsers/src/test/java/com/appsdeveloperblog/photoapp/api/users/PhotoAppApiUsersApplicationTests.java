package com.appsdeveloperblog.photoapp.api.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PhotoAppApiUsersApplicationTests {

	@Test
	public void contextLoads() {
	}

}
