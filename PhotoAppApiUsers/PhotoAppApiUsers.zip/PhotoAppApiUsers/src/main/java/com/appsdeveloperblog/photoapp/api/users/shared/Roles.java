package com.appsdeveloperblog.photoapp.api.users.shared;

public enum Roles {
	ROLE_USER, ROLE_ADMIN
}
